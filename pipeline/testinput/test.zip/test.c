#include <stdlib.h>
#include <stdio.h>

int main (int argc, const char* argv[])
{
    printf("Hello world!\n");
    return EXIT_SUCCESS;
}

