#include <stdlib.h>
#include <stdio.h>

int main (int argc, const char* argv[])
{
    printf("Helloe world!\n");
    return EXIT_SUCCESS;
}

